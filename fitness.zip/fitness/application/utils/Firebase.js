
//////////////////// FIREBASE

export default firebaseConfig = {
  apiKey: "AIzaSyCSFIibGIqv_Qx2aV2le8v9o8KesCJDsCs",
  authDomain: "trxx-052017.firebaseapp.com",
  databaseURL: "https://trxx-052017.firebaseio.com",
  projectId: "trxx-052017",
  storageBucket: "trxx-052017.appspot.com",
  messagingSenderId: "626707034670",
  appId: "1:626707034670:web:cceb8fa171df06b3"
};
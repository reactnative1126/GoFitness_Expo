<?php require'sidebar.php'; ?>

<!--Page Container--> 
<section class="page-container">
    <div class="page-content-wrapper">

        

        <!--Main Content-->

 <div class="content sm-gutter">
            <div class="container-fluid padding-25 sm-padding-10">
                <div class="row">
                    <div class="col-12">
                                        <div class="block-heading d-flex align-items-center title-pages">
                    <h5 class="text-truncate"><?=_NEW_EVENT?></h5>
                </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-block mb-4">

<form enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">


<div class="form-row">
  <div class="form-group col-md-12">
    <div class="block col-md-12" style="padding-bottom: 35px">
   
   <?php if( !empty($errors)): ?>
    	<div class="alert alert-danger animated fadeIn" role="alert" style="margin-top: 20px; margin-bottom: 0; text-transform: uppercase; font-size: 11px; text-align: center;">
    	    <?php echo $errors; ?>
    	</div>
   <?php endif; ?>
   
   <label class="control-label"><?=_EVENT_DATE?></label>
   <input type="text" id="event_date" name="event_date" value="<?=$event_date?>" class="form-control" placeholder="<?=_DATE_PLACEHOLDER?>" required>
   
   <label class="control-label"><?=_EVENT_START_TIME?></label>
   <input type="text" id="event_start_time" name="event_start_time" value="<?=$event_start_time?>" class="form-control" placeholder="<?=_START_DATE_PLACEHOLDER?>" required>
   
   <label class="control-label"><?=_EVENT_END_TIME?></label>
   <input type="text" id="event_end_time" name="event_end_time" value="<?=$event_end_time?>" class="form-control" placeholder="<?=_END_DATE_PLACEHOLDER?>" required>
   
   <label class="control-label"><?=_EVENT_AVAILABILITY?></label>
   <input type="text" maxlength="3" pattern="[0-9]+" value="<?=$event_availability?>" placeholder="<?=_AVAILABILITY_PLACEHOLDER?>" name="event_availability" class="form-control" required>
   
   <label class="control-label"><?=_EVENT_SCHEDULED_DATE?></label>
   <input type="text" id="event_scheduled_date" name="event_scheduled_date" value="<?=$event_scheduled_date?>" class="form-control" placeholder="<?=_SCHEDULED_DATE_PLACEHOLDER?>">
   
   <label class="control-label"><?=_EVENT_SCHEDULED_TIME?></label>
   <input type="text" id="event_scheduled_time" name="event_scheduled_time" value="<?=$event_scheduled_time?>" class="form-control" placeholder="<?=_SCHEDULED_TIME_PLACEHOLDER?>">

   <label class="control-label"><?=_COACH_NAME?></label>
   <select class="form-control" name="coach_id" required>
   <option value="" selected disabled hidden><?=_SELECT_COACH?></option>
   <?php foreach($coaches as $coach): ?>
         <option value="<?=$coach['objid']?>" <?if ($coach['objid'] === $coach_id) echo 'selected';?>><?=$coach['coach_name']?></option>
   <?php endforeach; ?>
   </select>
   
   <label class="control-label"><?=_CLASS_NAME?></label>
   <select class="form-control" name="class_id" required>
   <option value="" selected disabled hidden><?=_SELECT_CLASS?></option>
   <?php foreach($classes as $class): ?>
         <option value="<?=$class['objid']?>" <?if ($class['objid'] === $class_id) echo 'selected';?>><?=$class['class_name']?></option>
   <?php endforeach; ?>
   </select>
   
   <label class="control-label"><?=_PLACE_NAME?></label>
   <select class="form-control" name="place_id" required>
   <option value="" selected disabled hidden><?=_SELECT_PLACE?></option>
   <?php foreach($places as $place): ?>
         <option value="<?=$place['objid']?>" <?if ($place['objid'] === $place_id) echo 'selected';?>><?=$place['place_name']?></option>
   <?php endforeach; ?>
   </select>
   
   <label class="control-label"><?=_EVENT_PRIVATE?></label>
   <div class="row">
         <div class="col-sm-1">
         <?php $in = '1';
            if (strpos($in, $event_private) !== false) {
                echo '<div class="radio radio-success"> <input type="radio" name="event_private" id="radio5" value="'.$event_private.'" checked=""> <label for="radio5">'._YES.'</label> </div>';
            }else{
              echo '<div class="radio radio-success"> <input type="radio" name="event_private" id="radio5" value="'. $in .'"><label for="radio5">'._YES.'</label> </div>';
            }
         ?>
         </div>
         <div class="col-sm-1">
         <?php 
            $out = '0';
            if (strpos($out, $event_private) !== false) {
                echo '<div class="radio radio-danger"> <input type="radio" name="event_private" id="radio6" value="0" checked=""> <label for="radio6">'._NO.'</label> </div>';
            }else{
              echo '<div class="radio radio-danger"> <input type="radio" name="event_private" id="radio6" value="'. $out .'" checked=""> <label for="radio6">'._NO.'</label> </div>';
            }
         ?>
         </div>
   </div>
   
   <label class="control-label"><?=_ACTIVE?></label>
   <div class="row">
         <div class="col-sm-1">
         <?php $in = '1';
            if (strpos($in, $event_status) !== false) {
                echo '<div class="radio radio-success"> <input type="radio" name="event_status" id="radio7" value="'.$event_status.'" checked=""> <label for="radio7">'._YES.'</label> </div>';
            }else{
              echo '<div class="radio radio-success"> <input type="radio" name="event_status" id="radio7" value="'. $in .'" checked=""><label for="radio7">'._YES.'</label> </div>';
            }
         ?>
         </div>
         <div class="col-sm-1">
         <?php 
            $out = '0';
            if (strpos($out, $event_status) !== false) {
                echo '<div class="radio radio-danger"> <input type="radio" name="event_status" id="radio8" value="0" checked=""> <label for="radio8">'._NO.'</label> </div>';
            }else{
              echo '<div class="radio radio-danger"> <input type="radio" name="event_status" id="radio8" value="'. $out .'"> <label for="radio8">'._NO.'</label> </div>';
            }
         ?>
         </div>
   </div>
   
   <br />
   <br />
   
   <div class="action-button">
   <input type="submit" name="save" value="<?=_ADD?>" class="btn btn-embossed btn-primary">
   <input type="reset" name="reset" value="<?=_RESET?>" class="btn btn-embossed btn-danger">
   </div>

</div>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</section>

<?php require'sidebar.php'; ?>

<!--Page Container--> 
<section class="page-container">
    <div class="page-content-wrapper">

        

        <!--Main Content-->

 <div class="content sm-gutter">
            <div class="container-fluid padding-25 sm-padding-10">
                <div class="row">
                    <div class="col-12">
                                        <div class="block-heading d-flex align-items-center title-pages">
                    <h5 class="text-truncate"><?=_EDIT_GROUP?></h5>
                </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-block mb-4">

<form enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">

<div class="form-row">
  <div class="form-group col-md-12">
    <div class="block col-md-12" style="padding-bottom: 35px">

   <input type="hidden" value="<?php echo $group['objid']; ?>" name="group_id">
   <label class="control-label"><?=_NAME?></label>
   <input type="text" value="<?php echo $group['group_name']; ?>" placeholder="" name="group_name" class="form-control" required="">
   
   <label class="control-label"><?=_DETAILS?></label>
   <textarea value="" name="group_details" class="form-control" id="group_details"><?php echo $group['group_details']; ?></textarea>
   
   <label class="control-label"><?=_GROUP_USERS?></label>
   <select multiple="multiple" class="my-select form-control" name="user_id[]" required>
       
     <?php foreach($group_selected_users as $selected_users): ?>
    
      <option data-img-src="<?php echo SITE_URL ?>/images/users/<?php echo $selected_users['user_image']; ?>" value="<?php echo $selected_users['objid']; ?>" selected><?php echo $selected_users['name']; ?></option>
    
    <?php endforeach; ?>
    
    <?php foreach($group_not_selected_users as $not_selected_users): ?>
    <option data-img-src="<?php echo SITE_URL ?>/images/users/<?php echo $not_selected_users['user_image']; ?>" value="<?php echo $not_selected_users['objid']; ?>"><?php echo $not_selected_users['name']; ?></option>
    <?php endforeach; ?>
    
   </select>
   
   <label class="control-label"><?=_ACTIVE?></label>
   <div class="row">
                        <div class="col-sm-1">

                        <?php $in = '1';

if (strpos($in, $group['group_status']) !== false) {
    echo '<div class="radio radio-success"> <input type="radio" name="group_status" id="radio5" value="'. $group['group_status'] .'" checked=""> <label for="radio5"> '._YES.' </label> </div>';
}else{
  echo '<div class="radio radio-success"> <input type="radio" name="group_status" id="radio5" value="' . $in .'"> <label for="radio5"> '._YES.' </label> </div>';
}
                         ?>
                        </div>

                        <div class="col-sm-1">

                        <?php 
$out = '0';

if (strpos($out, $group['group_status']) !== false) {
    echo '<div class="radio radio-danger"> <input type="radio" name="group_status" id="radio6" value="0" checked=""> <label for="radio6">'._NO.'</label> </div>';
}else{
  echo '<div class="radio radio-danger"> <input type="radio" name="group_status" id="radio6" value="'. $out .'"> <label for="radio6">'._NO.'</label> </div>';
}
                         ?>
                        </div>

                    </div>
   <br />
   <br />
   <div class="action-button">
   <input type="submit" name="update" value="<?=_UPDATE?>" class="btn btn-embossed btn-primary" onclick="this.value='<?=_UPDATING?>';">
   </div>

   <?php if( !empty($errors)): ?>

		<div class="alert alert-danger animated fadeIn" role="alert" style="margin-top: 20px; margin-bottom: 0; text-transform: uppercase; font-size: 11px; text-align: center;">

		    <?php echo $errors; ?>

		</div>
		
   <?php endif; ?>
							
</div>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
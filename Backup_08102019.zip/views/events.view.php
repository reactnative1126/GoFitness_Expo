<?php require'sidebar.php'; ?>

<script type="text/javascript">
  $(document).ready( function () {
    $('#table_id').DataTable();
} );
</script>

<!--Page Container--> 
<section class="page-container">
    <div class="page-content-wrapper">

        

        <!--Main Content-->

 <div class="content sm-gutter">
            <div class="container-fluid padding-25 sm-padding-10">
                <div class="row">
                    <div class="col-12">
                        <div class="section-title">
                            <h5><?=_EVENTS?></h5>
                        </div>
                    </div>

<div class="col-12">
                        <div class="block table-block mb-4" style="margin-top: 20px;">

                            <div class="row">
                                <div class="table-responsive">
                                    
<table border="0" cellspacing="5" cellpadding="5">
        <tbody>
        <tr>
            <td><label class="control-label"><?=_EVENT_DATE?></label><input type="text" id="event_date" name="event_date" value="<?=date('Y-m-d')?>" class="form-control" placeholder="<?=_DATE_PLACEHOLDER?>" required></td>
        </tr>
    </tbody></table>
<table id="table_event" class="table table-striped table-bordered" cellspacing="0" width="100%" style="border-radius: 5px;">
    <thead>
            <tr>
                <th><?=_EVENT_DATE?></th>
                <th><?=_EVENT_START_TIME?></th>
                <th><?=_EVENT_END_TIME?></th>
                <th><?=_CLASS_NAME?></th>
                <th><?=_EVENT_AVAILABILITY?></th>
                <th><?=_EVENT_PRIVATE?></th>
                <th><?=_ACTIVE?></th>
                <th><?=_ACTIONS?></th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th><?=_EVENT_DATE?></th>
                <th><?=_EVENT_START_TIME?></th>
                <th><?=_EVENT_END_TIME?></th>
                <th><?=_CLASS_NAME?></th>
                <th><?=_EVENT_AVAILABILITY?></th>
                <th><?=_EVENT_PRIVATE?></th>
                <th><?=_ACTIVE?></th>
                <th><?=_ACTIONS?></th>
            </tr>
        </tfoot>

        <tbody>
        <?php foreach($events as $event): ?>
            <tr>
                <td><?php echo $event['event_date']; ?></td>
                <td><?php echo $event['event_start_time']; ?></td>
                <td><?php echo $event['event_end_time']; ?></td>
                <td><?php echo $event['class_name']; ?></td>
                <td><?php echo $event['event_availability']; ?></td>
                <td class="status">
                    <?php
                    $private = $event['event_private'];
                    if ($private == 1) {
                        echo '<span class="badge badge-pill bg-success">'._YES.'</span>';
                    }else{
                        echo '<span class="badge badge-pill bg-warning">'._NO.'</span>';
                    }
                    ?>
                </td>
                <td class="status">
                    <?php
                    $status = $event['event_status'];
                    if ($status == 1) {
                        echo '<span class="badge badge-pill bg-success">'._YES.'</span>';
                    }else{
                        echo '<span class="badge badge-pill bg-warning">'._NO.'</span>';
                    }
                    ?>
                </td>
                <td>
                <a href="../controller/edit_event.php?id=<?=$event['objid']?>" style="font-size: 14px;color: #000000;"><i class="fa fa-cog"></i></a>
                <a href="../controller/new_event.php?id=<?=$event['objid']?>" style="font-size: 14px;color: #777777;"><i class="fa fa-copy"></i></a>
              </td>
            </tr>
        <?php endforeach; ?>

        </tbody>
</table>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>

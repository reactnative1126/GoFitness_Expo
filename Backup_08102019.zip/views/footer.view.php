<!--Jquery
<script type="text/javascript" src="../assets/js/jquery-3.2.1.min.js"></script>-->
<script type="text/javascript" src="../assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="../assets/js/popper.min.js"></script>

<script type="text/javascript" src="../assets/js/modernizr.custom.js"></script>

<script type="text/javascript" src="../assets/plugins/customScroll/jquery.mCustomScrollbar.min.js"></script>
<script type="text/javascript" src="../assets/plugins/sortable2/sortable.min.js"></script>
<script type="text/javascript" src="../assets/plugins/date-range/moment.min.js"></script>
<script type="text/javascript" src="../assets/plugins/date-range/daterangepicker.js"></script>
<script type="text/javascript" src="../assets/plugins/timePicker/js/bootstrap-material-datetimepicker.js"></script>
<script type="text/javascript" src="../assets/plugins/data-tables/datatables.min.js"></script>
<script src="../assets/js/main.js"></script>
<script src="../assets/js/lightbox.js"></script>
<script src="../assets/js/custom.js"></script>

<script src="../assets/js/chosen.jquery.js" type="text/javascript"></script>
<script src="../assets/js/ImageSelect.jquery.js" type="text/javascript"></script>

  <script>
  
    $.fn.dataTable.ext.search.push(
        
        function( settings, data, dataIndex ) {
            
            if (settings.nTable.getAttribute('id') === 'table_event') {
                
                var selectedDate = $('#event_date').val();
                var eventDate = data[0];
                
                if (isNaN( selectedDate ) && isNaN( eventDate ) 
                        && selectedDate === eventDate)
                {
                    return true;
                }
                return false;
            }
            return true;
        }
    );
    
    $(function() {
        
      $('input[name="birthday"]').daterangepicker({
        singleDatePicker: true,
        showDropdowns: true,
        minYear: 1901,
        //startDate: moment().subtract(16, 'years'),
        maxYear: parseInt(moment().format('YYYY'),10),
        locale: { format: 'YYYY-MM-DD' }
      }, function(start, end, label) {
        // start.format('YYYY-MM-DD');
        // end.format('YYYY-MM-DD')
      });
      
      $('#event_date').bootstrapMaterialDatePicker({ format:'YYYY-MM-DD', weekStart : 0, time: false });
      $('#event_end_time').bootstrapMaterialDatePicker({ format:'HH:mm', date: false });
      $('#event_start_time').bootstrapMaterialDatePicker({ format:'HH:mm', date: false }).on('change', function(e, date)
            {
            $('#event_end_time').bootstrapMaterialDatePicker('setMinDate', date);
            });
      
      $('#event_scheduled_date').bootstrapMaterialDatePicker({ format:'YYYY-MM-DD', weekStart : 0, time: false });
      $('#event_scheduled_time').bootstrapMaterialDatePicker({ format:'HH:mm', date: false });
      
      $(document).ready(function() {
         
        var table = $('#table_event').DataTable( { 
            columnDefs: [ {
                targets: [ 0 ],
                orderData: [ 0, 1 ]
            }, {
                targets: [ 1 ],
                orderData: [ 1, 0 ]
            } ] } );
            
        $(".my-select").chosen({width:"100%"});
        
    	$('#event_scheduled_date').change(function(){
            if($(this).val() !== '' ){
        	   $('input[name="event_status"]')[1].checked = true;
        	}
    	});
    	
    	$('input:radio[name="event_status"]').change(function(){
    
    	    if ($('input[name="event_status"]')[0].checked === true){
    	        
    	        $("#event_scheduled_date").val('');
    	        $("#event_scheduled_time").val('');
    	    }
        });
        
        $('#event_date').keyup(function() {
            table.draw();
        });
        
        $('#event_date').change(function() {
            table.draw();
        });
        
        $("#filter_users").change(function(){
            
            if (this.value){
                window.location='../controller/users.php?filter=' + this.value
            }
            else {
                window.location='../controller/users.php'
            }
        });
        
      });
      
    });
</script>

<script async defer
  src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBAAWzJK7mIVJktjIrIzO8cbAvwcnyrngE&callback=initMap">
</script>

</body>
</html>
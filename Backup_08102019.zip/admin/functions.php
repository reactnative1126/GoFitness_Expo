<?php

define("API_ACCESS_KEY", "AIzaSyDuGRCSs2xlzBqgjMwmV2vCjG0kl7tyLYI");
define("HOST_NAME", "https://zobaba.com/");
define("FOLDER_NAME", "fitness");
define("ANDROID", "Android");
define("IOS", "iOS");
define("APPLICATION_COLOR", "#4284d5");
define("GREEN_COLOR", "#22BD3E");
define("RED_COLOR", "#C70039");
define("BLUE_COLOR", "#00008B");
define("TEXT_COLOR", "#3C3C40");

function connect($database){
    try{
        $connect = new PDO('mysql:host=localhost;dbname='. $database['db'], $database['user'], $database['pass'], array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES  \'UTF8\''));
        return $connect;
        
    }catch (PDOException $e){
        return false;
    }
}

function cleardata($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars ($data);
    return $data;
}

function actual_page(){
    
    return isset($_GET['p']) ? (int)$_GET['p'] : 1;
}

function number_pages($items_per_page, $connect){

    $total_places = $connect->prepare('SELECT FOUND_ROWS() AS total');
    $total_places->execute();
    $total_places = $total_places->fetch()['total'];

    $number_pages = ceil($total_places / $items_per_page);
    return $number_pages;
}


////////////////////////////////////////////////////////////////////////////////
// Users
////////////////////////////////////////////////////////////////////////////////

function get_all_users($connect)
{
    $sentence = $connect->prepare('SELECT USR.objid, USR.unique_id, USR.user_id, USR.name, USR.email, USR.phone, USR.user_weight, USR.user_height, USR.user_age, USR.user_sex, USR.user_status, 
	case when SUBS.objid IS NULL then 0 else SUBS.objid end as SUBS_OBJID,
	case when SUBS.subscription_name IS NULL then "" else SUBS.subscription_name end as SUBS_NAME,
	case when (USR.freeze_created_at IS NOT NULL and USR.user_status=0) then 1 else 0 end as USER_IN_FREEZE, 
	USR.user_birthdate, USR.user_image
	FROM TABLE_USER USR LEFT JOIN TABLE_SUBSCRIPTION SUBS ON SUBS.OBJID=USR.user2subs WHERE USR.user_status >= 0 AND USR.priv_class = 0 ORDER BY USR.created_at DESC');

    $sentence->execute();
    return $sentence->fetchAll(PDO::FETCH_ASSOC);
}

function get_active_users($connect)
{
    $sentence = $connect->prepare('SELECT USR.objid, USR.unique_id, USR.user_id, USR.name, USR.email, USR.phone, USR.user_weight, USR.user_height, USR.user_age, USR.user_sex, USR.user_status, 
	case when SUBS.objid IS NULL then 0 else SUBS.objid end as SUBS_OBJID,
	case when SUBS.subscription_name IS NULL then "" else SUBS.subscription_name end as SUBS_NAME,
	case when (USR.freeze_created_at IS NOT NULL and USR.user_status=0) then 1 else 0 end as USER_IN_FREEZE,
	USR.user_birthdate, USR.user_image
	FROM TABLE_USER USR 
	INNER JOIN TABLE_SUBSCRIPTION SUBS 
	      ON SUBS.OBJID=USR.user2subs 
          AND SUBS.subscription_period > 0
          AND CURDATE() >= DATE(USR.subs_created_at)
          AND CURDATE() <= (case when (USR.freeze_created_at IS NOT NULL AND USR.freeze_ends_at IS NOT NULL)  then 
DATE_ADD(DATE_ADD(DATE(USR.subs_created_at), INTERVAL SUBS.subscription_period MONTH), INTERVAL DATEDIFF(USR.freeze_ends_at, USR.freeze_created_at) DAY) 
else DATE_ADD(DATE(USR.subs_created_at), INTERVAL SUBS.subscription_period MONTH) end)
	WHERE USR.priv_class=0 AND USR.user_status > 0 AND USR.user2subs > 0
	ORDER BY USR.created_at DESC');

    $sentence->execute();
    return $sentence->fetchAll(PDO::FETCH_ASSOC);
}

function get_inactive_users($connect)
{
    $sentence = $connect->prepare('SELECT USR.objid, USR.unique_id, USR.user_id, USR.name, USR.email, USR.phone, USR.user_weight, USR.user_height, USR.user_age, USR.user_sex, USR.user_status, 
	case when SUBS.objid IS NULL then 0 else SUBS.objid end as SUBS_OBJID,
	case when SUBS.subscription_name IS NULL then "" else SUBS.subscription_name end as SUBS_NAME, 
	case when (USR.freeze_created_at IS NOT NULL and USR.user_status=0) then 1 else 0 end as USER_IN_FREEZE,
	USR.user_birthdate, USR.user_image
	FROM TABLE_USER USR 
	LEFT JOIN TABLE_SUBSCRIPTION SUBS 
	     ON SUBS.OBJID=USR.user2subs 
	WHERE USR.user_status = 0
	AND USR.priv_class = 0 
	ORDER BY USR.created_at DESC');

    $sentence->execute();
    return $sentence->fetchAll(PDO::FETCH_ASSOC);
}

function get_users_with_no_membership($connect)
{
    $sentence = $connect->prepare('SELECT USR.objid, USR.unique_id, USR.user_id, USR.name, USR.email, USR.phone, USR.user_weight, USR.user_height, USR.user_age, USR.user_sex, USR.user_status, 
	case when SUBS.objid IS NULL then 0 else SUBS.objid end as SUBS_OBJID,
	case when SUBS.subscription_name IS NULL then "" else SUBS.subscription_name end as SUBS_NAME,
	case when (USR.freeze_created_at IS NOT NULL and USR.user_status=0) then 1 else 0 end as USER_IN_FREEZE,
	USR.user_birthdate, USR.user_image
	FROM TABLE_USER USR 
	LEFT JOIN TABLE_SUBSCRIPTION SUBS 
	     ON SUBS.OBJID=USR.user2subs 
	     AND SUBS.subscription_period > 0
	WHERE USR.user_status > 0 
	AND USR.user2subs = 0 
	AND USR.priv_class = 0 
	ORDER BY USR.created_at DESC');

    $sentence->execute();
    return $sentence->fetchAll(PDO::FETCH_ASSOC);
}

function get_expired_users($connect)
{
    $sentence = $connect->prepare('SELECT USR.objid, USR.unique_id, USR.user_id, USR.name, USR.email, USR.phone, USR.user_weight, USR.user_height, USR.user_age, USR.user_sex, USR.user_status, 
	case when SUBS.objid IS NULL then 0 else SUBS.objid end as SUBS_OBJID,
	case when SUBS.subscription_name IS NULL then "" else SUBS.subscription_name end as SUBS_NAME,
	case when (USR.freeze_created_at IS NOT NULL and USR.user_status=0) then 1 else 0 end as USER_IN_FREEZE,
	USR.user_birthdate, USR.user_image
	FROM TABLE_USER USR 
        INNER JOIN TABLE_SUBSCRIPTION SUBS 
	     ON SUBS.OBJID=USR.user2subs 
	     AND SUBS.subscription_period > 0
	     AND CURDATE() > (case when (USR.freeze_created_at IS NOT NULL AND USR.freeze_ends_at IS NOT NULL)  then 
DATE_ADD(DATE_ADD(DATE(USR.subs_created_at), INTERVAL SUBS.subscription_period MONTH), INTERVAL DATEDIFF(USR.freeze_ends_at, USR.freeze_created_at) DAY) 
else DATE_ADD(DATE(USR.subs_created_at), INTERVAL SUBS.subscription_period MONTH) end)
	WHERE USR.user_status > 0
	AND USR.priv_class = 0 
	ORDER BY USR.created_at DESC');

    $sentence->execute();
    return $sentence->fetchAll(PDO::FETCH_ASSOC);
}

function get_expired_soon_users($connect)
{
    $sentence = $connect->prepare('SELECT USR.objid, USR.unique_id, USR.user_id, USR.name, USR.email, USR.phone, USR.user_weight, USR.user_height, USR.user_age, USR.user_sex, USR.user_status, 
	case when SUBS.objid IS NULL then 0 else SUBS.objid end as SUBS_OBJID,
	case when SUBS.subscription_name IS NULL then "" else SUBS.subscription_name end as SUBS_NAME,
	case when (USR.freeze_created_at IS NOT NULL and USR.user_status=0) then 1 else 0 end as USER_IN_FREEZE, 
	USR.user_birthdate, USR.user_image
	FROM TABLE_USER USR 
        INNER JOIN TABLE_SUBSCRIPTION SUBS 
	     ON SUBS.OBJID=USR.user2subs 
	     AND SUBS.subscription_period > 0
	     AND (case when (USR.freeze_created_at IS NOT NULL AND USR.freeze_ends_at IS NOT NULL)  then 
DATE_ADD(DATE_ADD(DATE(USR.subs_created_at), INTERVAL SUBS.subscription_period MONTH), INTERVAL DATEDIFF(USR.freeze_ends_at, USR.freeze_created_at) DAY) 
else DATE_ADD(DATE(USR.subs_created_at), INTERVAL SUBS.subscription_period MONTH) end) BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)
	WHERE USR.user_status > 0
	AND USR.priv_class = 0 
	ORDER BY USR.created_at DESC');

    $sentence->execute();
    return $sentence->fetchAll(PDO::FETCH_ASSOC);
}

function get_freezed_users($connect)
{
    $sentence = $connect->prepare('SELECT USR.objid, USR.unique_id, USR.user_id, USR.name, USR.email, USR.phone, USR.user_weight, USR.user_height, USR.user_age, USR.user_sex, USR.user_status, 
	case when SUBS.objid IS NULL then 0 else SUBS.objid end as SUBS_OBJID,
	case when SUBS.subscription_name IS NULL then "" else SUBS.subscription_name end as SUBS_NAME,
	case when (USR.freeze_created_at IS NOT NULL and USR.user_status=0) then 1 else 0 end as USER_IN_FREEZE,
	USR.user_birthdate, USR.user_image
	FROM TABLE_USER USR 
	LEFT JOIN TABLE_SUBSCRIPTION SUBS 
	     ON SUBS.OBJID=USR.user2subs 
	WHERE USR.user_status = 0
	AND USR.priv_class = 0 
	AND USR.freeze_created_at IS NOT NULL
	ORDER BY USR.created_at DESC');

    $sentence->execute();
    return $sentence->fetchAll(PDO::FETCH_ASSOC);
}

function get_not_enrolled_users($connect)
{
    $sentence = $connect->prepare('SELECT USR.objid, USR.unique_id, USR.user_id, USR.name, USR.email, USR.phone, USR.user_weight, USR.user_height, USR.user_age, USR.user_sex, USR.user_status, 
	case when SUBS.objid IS NULL then 0 else SUBS.objid end as SUBS_OBJID,
	case when SUBS.subscription_name IS NULL then "" else SUBS.subscription_name end as SUBS_NAME,
	case when (USR.freeze_created_at IS NOT NULL and USR.user_status=0) then 1 else 0 end as USER_IN_FREEZE,
	USR.user_birthdate, USR.user_image
FROM TABLE_USER USR 
INNER JOIN TABLE_SUBSCRIPTION SUBS 
     ON SUBS.OBJID=USR.user2subs 
          AND SUBS.subscription_period > 0
          AND CURDATE() >= DATE(USR.subs_created_at)
          AND CURDATE() <= (case when (USR.freeze_created_at IS NOT NULL AND USR.freeze_ends_at IS NOT NULL)  then 
DATE_ADD(DATE_ADD(DATE(USR.subs_created_at), INTERVAL SUBS.subscription_period MONTH), INTERVAL DATEDIFF(USR.freeze_ends_at, USR.freeze_created_at) DAY) 
else DATE_ADD(DATE(USR.subs_created_at), INTERVAL SUBS.subscription_period MONTH) end)
INNER JOIN (
        SELECT enroll2user, max(enroll_time) as ENROLL_TIME 
        FROM TABLE_ENROLL 
        WHERE enroll_status > 0
        GROUP BY enroll2user
        ORDER BY ENROLL_TIME DESC
    ) ENRL 
    ON ENRL.enroll2user = USR.objid
    AND ENRL.ENROLL_TIME < DATE_ADD(CURDATE(), INTERVAL -14 DAY) 
WHERE USR.priv_class=0 AND USR.user_status > 0 AND USR.user2subs > 0
GROUP BY ENRL.enroll2user, ENRL.enroll_time');

    $sentence->execute();
    return $sentence->fetchAll(PDO::FETCH_ASSOC);
}

function number_users($connect){

    $total_numbers = $connect->prepare('SELECT * FROM TABLE_USER USR WHERE USR.user_status >= 0 AND USR.priv_class = 0 ');
    $total_numbers->execute(array());
    $total_numbers->fetchAll();
    $total = $total_numbers->rowCount();
    return $total;
}

function id_user($id){
    return (int)cleardata($id);
}

function get_user_per_id($connect, $id){
    $sentence = $connect->query("SELECT * FROM TABLE_USER WHERE objid = $id LIMIT 1");
    $sentence = $sentence->fetchAll();
    return ($sentence) ? $sentence : false;
}

function check_user_id($connect, $id){
    
    $sentence = $connect->prepare("SELECT * FROM TABLE_USER WHERE user_id=$id LIMIT 1");
    $sentence->execute();
    if ($sentence) {
        $row_count = $sentence->fetchColumn();
        if ($row_count > 0) {
            return 1;
        }
    }
    return 0;
}

function check_user_email($connect, $email){
    
    $sentence = $connect->prepare("SELECT * FROM TABLE_USER WHERE email=$email LIMIT 1");
    $sentence->execute();
    if ($sentence) {
        $row_count = $sentence->fetchColumn();
        if ($row_count > 0) {
            return 1;
        }
    }
    return 0;
}
     
////////////////////////////////////////////////////////////////////////////////
// Events
////////////////////////////////////////////////////////////////////////////////

function get_all_events($connect)
{
    $sentence = $connect->prepare('SELECT EVENT.objid, EVENT.event_date, DATE_FORMAT(EVENT.event_start_time, "%H:%i") as event_start_time, DATE_FORMAT(EVENT.event_end_time, "%H:%i") as event_end_time, EVENT.event_availability, EVENT.event_status, EVENT.event2class, CLASS.class_name, EVENT.event2place, PLACE.place_name, 
	case when (EVENT.event_scheduled_date IS NOT NULL) then event_scheduled_date else "" end as EVENT_SCHEDULED_DATE, 
	case when (EVENT.event_scheduled_time IS NOT NULL) then DATE_FORMAT(EVENT.event_scheduled_time, "%H:%i") else "" end as EVENT_SCHEDULED_TIME, EVENT.event_private
	 from TABLE_EVENT EVENT INNER JOIN TABLE_PLACE PLACE ON PLACE.OBJID=EVENT.event2place INNER JOIN TABLE_CLASS CLASS ON CLASS.OBJID=EVENT.event2class LEFT OUTER JOIN TABLE_COACH COACH ON COACH.OBJID=EVENT.event2coach ORDER BY EVENT.event_date DESC');
    $sentence->execute();
    return $sentence->fetchAll(PDO::FETCH_ASSOC);
}

function id_event($id){
    
    return (int)cleardata($id);
}

function get_event_per_id($connect, $id){
    
    $sentence = $connect->prepare('SELECT EVENT.objid, EVENT.event_date as event_date, 
    DATE_FORMAT(EVENT.event_start_time, "%H:%i") as event_start_time, 
DATE_FORMAT(EVENT.event_end_time, "%H:%i") as event_end_time,
EVENT.event_status as event_status,
EVENT.event_availability,
CLSS.objid as class_id,
CLSS.class_name as class_name,
CLSS.class_image as class_image,
PLC.objid as place_id,
PLC.place_name as place_name,
EVENT.event_private as event_private,
COACH.objid as coach_id,
COACH.coach_name as coach_name,
EVENT.event_scheduled_date as event_scheduled_date,
DATE_FORMAT(EVENT.event_scheduled_time, "%H:%i") as event_scheduled_time
FROM TABLE_EVENT EVENT
INNER JOIN TABLE_CLASS CLSS
      on CLSS.objid=EVENT.event2class
INNER JOIN TABLE_PLACE PLC
      on PLC.OBJID=EVENT.event2place
LEFT OUTER JOIN TABLE_COACH COACH 
      ON COACH.OBJID=EVENT.event2coach
WHERE EVENT.objid=?');
    $sentence->execute([$id]);
    $sentence = $sentence->fetchAll();
    return ($sentence) ? $sentence : false;
}

function number_events($connect, $eventDate){

    $total_numbers = $connect->prepare('SELECT * FROM TABLE_EVENT WHERE event_date=Date($eventDate)');
    $total_numbers->execute(array());
    $total_numbers->fetchAll();
    $total = $total_numbers->rowCount();
    return $total;
}

function check_event_exist($connect, $eventDate, $eventStartTime, $eventEndTime, $placeID){
    
    $sql = "SELECT * from TABLE_EVENT WHERE event_date=Date('$eventDate') AND event2place=$placeID AND ((TIME_TO_SEC(event_start_time)+60 >= TIME_TO_SEC(Time('$eventStartTime')) AND TIME_TO_SEC(event_start_time)+60 <= TIME_TO_SEC(Time('$eventEndTime')) ) OR (TIME_TO_SEC(event_end_time)-60 >= TIME_TO_SEC(Time('$eventStartTime')) AND TIME_TO_SEC(event_end_time)-60 <= TIME_TO_SEC(Time('$eventEndTime')) ))";
    $sentence = $connect->prepare($sql);
    $sentence->execute();
    $sentence->fetchAll();
    $total = $sentence->rowCount();
    return $total;
}

function check_update_event_exist($connect, $eventId, $eventDate, $eventStartTime, $eventEndTime, $placeID){
    
    $sql = "SELECT * from TABLE_EVENT WHERE event_date=Date('$eventDate') AND event2place=$placeID AND ((TIME_TO_SEC(event_start_time)+60 >= TIME_TO_SEC(Time('$eventStartTime')) AND TIME_TO_SEC(event_start_time)+60 <= TIME_TO_SEC(Time('$eventEndTime')) ) OR (TIME_TO_SEC(event_end_time)-60 >= TIME_TO_SEC(Time('$eventStartTime')) AND TIME_TO_SEC(event_end_time)-60 <= TIME_TO_SEC(Time('$eventEndTime')) )) AND objid!=$eventId";
    $sentence = $connect->prepare($sql);
    $sentence->execute();
    $sentence->fetchAll();
    $total = $sentence->rowCount();
    
    return $total;
}

////////////////////////////////////////////////////////////////////////////////
// Places
////////////////////////////////////////////////////////////////////////////////

function get_all_places($connect)
{
    $sentence = $connect->prepare('SELECT objid, place_name, place_latitude, place_longitude, place_status FROM TABLE_PLACE ORDER BY objid ASC, place_status DESC');

    $sentence->execute();
    return $sentence->fetchAll(PDO::FETCH_ASSOC);
}

function id_place($place_id){
    return (int)cleardata($place_id);
}

function get_place_per_id($connect, $place_id){
    $sentence = $connect->query("SELECT * FROM TABLE_PLACE WHERE objid = $place_id LIMIT 1");
    $sentence = $sentence->fetchAll();
    return ($sentence) ? $sentence : false;
}

function number_places($connect){

    $total_numbers = $connect->prepare('SELECT * FROM TABLE_PLACE');
    $total_numbers->execute(array());
    $total_numbers->fetchAll();
    $total = $total_numbers->rowCount();
    return $total;
}

////////////////////////////////////////////////////////////////////////////////
// Coaches
////////////////////////////////////////////////////////////////////////////////

function get_all_coaches($connect)
{
    $sentence = $connect->prepare("SELECT objid, coach_name, coach_details, coach_image, coach_status FROM TABLE_COACH ORDER BY coach_status DESC, coach_name ASC");

    $sentence->execute();
    return $sentence->fetchAll(PDO::FETCH_ASSOC);
}

function id_coach($id){
    return (int)cleardata($id);
}

function get_coach_per_id($connect, $id){
    $sentence = $connect->query("SELECT objid, coach_name, coach_details, coach_image, coach_status FROM TABLE_COACH WHERE objid = $id");
    $sentence = $sentence->fetchAll();
    return ($sentence) ? $sentence : false;
}

function number_coaches($connect){

$total_numbers = $connect->prepare('SELECT * FROM TABLE_COACH');
$total_numbers->execute(array());
$total_numbers->fetchAll();
$total = $total_numbers->rowCount();
return $total;

}


////////////////////////////////////////////////////////////////////////////////
// Subscriptions
////////////////////////////////////////////////////////////////////////////////

function get_all_subscriptions($connect)
{
    $sentence = $connect->prepare("SELECT objid, subscription_name, subscription_details, subscription_period, subscription_bank, subscription_price, subscription_status FROM TABLE_SUBSCRIPTION ORDER BY subscription_status DESC, subscription_name ASC");

    $sentence->execute();
    return $sentence->fetchAll(PDO::FETCH_ASSOC);
}

function id_subscription($id){
    return (int)cleardata($id);
}

function get_subscription_per_id($connect, $id){
    $sentence = $connect->query("SELECT objid, subscription_name, subscription_details, subscription_period, subscription_bank, subscription_price, subscription_status FROM TABLE_SUBSCRIPTION WHERE objid = $id");
    $sentence = $sentence->fetchAll();
    return ($sentence) ? $sentence : false;
}

function number_subscriptions($connect){

$total_numbers = $connect->prepare('SELECT * FROM TABLE_SUBSCRIPTION');
$total_numbers->execute(array());
$total_numbers->fetchAll();
$total = $total_numbers->rowCount();
return $total;

}

////////////////////////////////////////////////////////////////////////////////
// Groups
////////////////////////////////////////////////////////////////////////////////

function get_all_groups($connect)
{
    $sentence = $connect->prepare("SELECT objid, group_name, group_details, group_status FROM TABLE_GROUP ORDER BY group_status DESC, group_name ASC");

    $sentence->execute();
    return $sentence->fetchAll(PDO::FETCH_ASSOC);
}

function id_group($id){
    return (int)cleardata($id);
}

function get_group_per_id($connect, $id){
    
    $sentence = $connect->query("SELECT objid, group_name, group_details, group_status FROM TABLE_GROUP WHERE objid = $id");
    $sentence = $sentence->fetchAll();
    return ($sentence) ? $sentence : false;
}

function number_groups($connect){

    $total_numbers = $connect->prepare('SELECT * FROM TABLE_GROUP');
    $total_numbers->execute(array());
    $total_numbers->fetchAll();
    $total = $total_numbers->rowCount();
    return $total;
}

function group_active_users($connect)
{
    $sentence = $connect->prepare('SELECT USR.*
	FROM TABLE_USER USR 
	INNER JOIN TABLE_SUBSCRIPTION SUBS 
	      ON SUBS.OBJID=USR.user2subs 
          AND SUBS.subscription_period > 0
          AND CURDATE() >= DATE(USR.subs_created_at)
          AND CURDATE() <= (case when (USR.freeze_created_at IS NOT NULL AND USR.freeze_ends_at IS NOT NULL)  then 
DATE_ADD(DATE_ADD(DATE(USR.subs_created_at), INTERVAL SUBS.subscription_period MONTH), INTERVAL DATEDIFF(USR.freeze_ends_at, USR.freeze_created_at) DAY) 
else DATE_ADD(DATE(USR.subs_created_at), INTERVAL SUBS.subscription_period MONTH) end)
	WHERE USR.priv_class=0 AND USR.user_status > 0 AND USR.user2subs > 0
	ORDER BY USR.created_at DESC'); 
    $sentence->execute();
    return $sentence->fetchAll();
}

function group_selected_users($connect){

	if (isset($_GET['group_id']) && !empty($_GET['group_id'])) {

		$id = intval($_GET['group_id']);

		$sentence = $connect->prepare('SELECT USR.objid, USR.name, USR.user_image FROM TABLE_USER USR 
        INNER JOIN TABLE_GROUP_USERS GU
              ON GU.groupusers2user=USR.objid
              AND GU.groupusers2group=?
        INNER JOIN TABLE_SUBSCRIPTION SUBS 
	      ON SUBS.OBJID=USR.user2subs 
          AND SUBS.subscription_period > 0
          AND CURDATE() >= DATE(USR.subs_created_at)
          AND CURDATE() <= (case when (USR.freeze_created_at IS NOT NULL AND USR.freeze_ends_at IS NOT NULL)  then 
            DATE_ADD(DATE_ADD(DATE(USR.subs_created_at), INTERVAL SUBS.subscription_period MONTH), INTERVAL DATEDIFF(USR.freeze_ends_at, USR.freeze_created_at) DAY) 
            else DATE_ADD(DATE(USR.subs_created_at), INTERVAL SUBS.subscription_period MONTH) end)
        WHERE USR.priv_class=0 AND USR.user_status > 0 AND USR.user2subs > 0
        ORDER BY USR.created_at DESC');
		$sentence->execute([$id]);
		return $sentence->fetchAll();
	}
}

function group_not_selected_users($connect){
    
  if (isset($_GET['group_id']) && !empty($_GET['group_id'])) {

		$id = intval($_GET['group_id']);

		$sentence = $connect->prepare('SELECT USR.objid, USR.name, USR.user_image
        FROM TABLE_USER USR 
        INNER JOIN TABLE_SUBSCRIPTION SUBS 
	      ON SUBS.OBJID=USR.user2subs 
          AND SUBS.subscription_period > 0
          AND CURDATE() >= DATE(USR.subs_created_at)
          AND CURDATE() <= (case when (USR.freeze_created_at IS NOT NULL AND USR.freeze_ends_at IS NOT NULL)  then 
            DATE_ADD(DATE_ADD(DATE(USR.subs_created_at), INTERVAL SUBS.subscription_period MONTH), INTERVAL DATEDIFF(USR.freeze_ends_at, USR.freeze_created_at) DAY) 
            else DATE_ADD(DATE(USR.subs_created_at), INTERVAL SUBS.subscription_period MONTH) end)
        WHERE USR.objid NOT IN (SELECT GU.groupusers2user from TABLE_GROUP_USERS GU WHERE GU.groupusers2group=?)
        AND USR.priv_class=0 AND USR.user_status > 0 AND USR.user2subs > 0
        ORDER BY USR.created_at DESC');
		$sentence->execute([$id]);
		return $sentence->fetchAll();
  }
}

////////////////////////////////////////////////////////////////////////////////
// Classes
////////////////////////////////////////////////////////////////////////////////

function get_all_classes($connect)
{
    $sentence = $connect->prepare("SELECT objid, class_name, class_details, class_image, class_status FROM TABLE_CLASS ORDER BY class_status DESC, class_name ASC");

    $sentence->execute();
    return $sentence->fetchAll(PDO::FETCH_ASSOC);
}

function id_class($id){
    return (int)cleardata($id);
}

function get_class_per_id($connect, $id){
    $sentence = $connect->query("SELECT objid, class_name, class_details, class_image, class_status FROM TABLE_CLASS WHERE objid = $id");
    $sentence = $sentence->fetchAll();
    return ($sentence) ? $sentence : false;
}

function number_classes($connect){

$total_numbers = $connect->prepare('SELECT * FROM TABLE_CLASS');
$total_numbers->execute(array());
$total_numbers->fetchAll();
$total = $total_numbers->rowCount();
return $total;

}


////////////////////////////////////////////////////////////////////////////////
// Payments
////////////////////////////////////////////////////////////////////////////////

function get_all_payments($connect)
{
    $sentence = $connect->prepare("SELECT objid, class_name, class_details, class_image, class_status FROM TABLE_CLASS ORDER BY class_status DESC, class_name ASC");

    $sentence->execute();
    return $sentence->fetchAll(PDO::FETCH_ASSOC);
}

function id_payment($id){
    return (int)cleardata($id);
}

function get_payment_per_id($connect, $id){
    $sentence = $connect->query("SELECT objid, class_name, class_details, class_image, class_status FROM TABLE_CLASS WHERE objid = $id");
    $sentence = $sentence->fetchAll();
    return ($sentence) ? $sentence : false;
}

function number_payments($connect){

$total_numbers = $connect->prepare('SELECT * FROM TABLE_CLASS');
$total_numbers->execute(array());
$total_numbers->fetchAll();
$total = $total_numbers->rowCount();
return $total;

}

///////////////////////////////////////////////////////////////////////////////
//// EXERCISES
///////////////////////////////////////////////////////////////////////////////

function get_all_exercises($connect)
{
    $sentence = $connect->prepare("SELECT SQL_CALC_FOUND_ROWS exercises.*, equipments.equipment_title AS equipment_title, levels.level_title AS level_title, GROUP_CONCAT(bodyparts.bodypart_title) AS bodypart_title FROM exercises JOIN exercises_bodyparts ON exercises_bodyparts.exercise_id = exercises.exercise_id JOIN equipments ON exercises.exercise_equipment = equipments.equipment_id JOIN levels ON exercises.exercise_level = levels.level_id JOIN bodyparts ON bodyparts.bodypart_id = exercises_bodyparts.bodypart_id GROUP BY exercises.exercise_id ORDER BY exercises.exercise_id DESC");

    $sentence->execute();
    return $sentence->fetchAll(PDO::FETCH_ASSOC);
}

function id_exercise($id){
    return (int)cleardata($id);
}

function get_exercise_per_id($connect, $id){
    $sentence = $connect->query("SELECT exercises.*,equipments.equipment_title AS equipment_title, levels.level_title AS level_title, GROUP_CONCAT(bodyparts.bodypart_title) AS bodypart_title FROM exercises JOIN exercises_bodyparts ON exercises_bodyparts.exercise_id = exercises.exercise_id JOIN bodyparts ON bodyparts.bodypart_id = exercises_bodyparts.bodypart_id JOIN equipments ON exercises.exercise_equipment = equipments.equipment_id JOIN levels ON exercises.exercise_level = levels.level_id WHERE exercises.exercise_id = $id GROUP BY exercises.exercise_id LIMIT 1");
    $sentence = $sentence->fetchAll();
    return ($sentence) ? $sentence : false;
}

function number_exercises($connect){

$total_numbers = $connect->prepare('SELECT * FROM exercises');
$total_numbers->execute(array());
$total_numbers->fetchAll();
$total = $total_numbers->rowCount();
return $total;

}

function selected_exercises1($connect){

if (isset($_GET['id']) && !empty($_GET['id'])) {

$id = intval($_GET['id']);

$sentence = $connect->prepare('SELECT exercises.exercise_title, exercises.exercise_id, exercises.exercise_image FROM exercises JOIN we_day1 ON we_day1.exercise_id = exercises.exercise_id JOIN workouts ON we_day1.workout_id = ? GROUP BY we_day1.exercise_id');
$sentence->execute([$id]);
return $sentence->fetchAll();

}}

function not_selected_exercises1($connect){

 if (isset($_GET['id']) && !empty($_GET['id'])) {

$id = intval($_GET['id']);

$sentence = $connect->prepare('SELECT exercises.exercise_title, exercises.exercise_id, exercises.exercise_image FROM exercises WHERE exercises.exercise_id NOT IN (SELECT we_day1.exercise_id FROM we_day1 WHERE we_day1.workout_id = ? GROUP BY we_day1.exercise_id)');
$sentence->execute([$id]);
return $sentence->fetchAll();

}}

function selected_exercises2($connect){

if (isset($_GET['id']) && !empty($_GET['id'])) {

$id = intval($_GET['id']);

$sentence = $connect->prepare('SELECT exercises.exercise_title, exercises.exercise_id, exercises.exercise_image FROM exercises JOIN we_day2 ON we_day2.exercise_id = exercises.exercise_id JOIN workouts ON we_day2.workout_id = ? GROUP BY we_day2.exercise_id');
$sentence->execute([$id]);
return $sentence->fetchAll();

}}

function not_selected_exercises2($connect){

 if (isset($_GET['id']) && !empty($_GET['id'])) {

$id = intval($_GET['id']);

$sentence = $connect->prepare('SELECT exercises.exercise_title, exercises.exercise_id, exercises.exercise_image FROM exercises WHERE exercises.exercise_id NOT IN (SELECT we_day2.exercise_id FROM we_day2 WHERE we_day2.workout_id = ? GROUP BY we_day2.exercise_id)');
$sentence->execute([$id]);
return $sentence->fetchAll();

}}

function selected_exercises3($connect){

if (isset($_GET['id']) && !empty($_GET['id'])) {

$id = intval($_GET['id']);

$sentence = $connect->prepare('SELECT exercises.exercise_title, exercises.exercise_id, exercises.exercise_image FROM exercises JOIN we_day3 ON we_day3.exercise_id = exercises.exercise_id JOIN workouts ON we_day3.workout_id = ? GROUP BY we_day3.exercise_id');
$sentence->execute([$id]);
return $sentence->fetchAll();

}}

function not_selected_exercises3($connect){

 if (isset($_GET['id']) && !empty($_GET['id'])) {

$id = intval($_GET['id']);

$sentence = $connect->prepare('SELECT exercises.exercise_title, exercises.exercise_id, exercises.exercise_image FROM exercises WHERE exercises.exercise_id NOT IN (SELECT we_day3.exercise_id FROM we_day3 WHERE we_day3.workout_id = ? GROUP BY we_day3.exercise_id)');
$sentence->execute([$id]);
return $sentence->fetchAll();

}}

function selected_exercises4($connect){

if (isset($_GET['id']) && !empty($_GET['id'])) {

$id = intval($_GET['id']);

$sentence = $connect->prepare('SELECT exercises.exercise_title, exercises.exercise_id, exercises.exercise_image FROM exercises JOIN we_day4 ON we_day4.exercise_id = exercises.exercise_id JOIN workouts ON we_day4.workout_id = ? GROUP BY we_day4.exercise_id');
$sentence->execute([$id]);
return $sentence->fetchAll();

}}

function not_selected_exercises4($connect){

 if (isset($_GET['id']) && !empty($_GET['id'])) {

$id = intval($_GET['id']);

$sentence = $connect->prepare('SELECT exercises.exercise_title, exercises.exercise_id, exercises.exercise_image FROM exercises WHERE exercises.exercise_id NOT IN (SELECT we_day4.exercise_id FROM we_day4 WHERE we_day4.workout_id = ? GROUP BY we_day4.exercise_id)');
$sentence->execute([$id]);
return $sentence->fetchAll();

}}

function selected_exercises5($connect){

if (isset($_GET['id']) && !empty($_GET['id'])) {

$id = intval($_GET['id']);

$sentence = $connect->prepare('SELECT exercises.exercise_title, exercises.exercise_id, exercises.exercise_image FROM exercises JOIN we_day5 ON we_day5.exercise_id = exercises.exercise_id JOIN workouts ON we_day5.workout_id = ? GROUP BY we_day5.exercise_id');
$sentence->execute([$id]);
return $sentence->fetchAll();

}}

function not_selected_exercises5($connect){

 if (isset($_GET['id']) && !empty($_GET['id'])) {

$id = intval($_GET['id']);

$sentence = $connect->prepare('SELECT exercises.exercise_title, exercises.exercise_id, exercises.exercise_image FROM exercises WHERE exercises.exercise_id NOT IN (SELECT we_day5.exercise_id FROM we_day5 WHERE we_day5.workout_id = ? GROUP BY we_day5.exercise_id)');
$sentence->execute([$id]);
return $sentence->fetchAll();

}}

function selected_exercises6($connect){

if (isset($_GET['id']) && !empty($_GET['id'])) {

$id = intval($_GET['id']);

$sentence = $connect->prepare('SELECT exercises.exercise_title, exercises.exercise_id, exercises.exercise_image FROM exercises JOIN we_day6 ON we_day6.exercise_id = exercises.exercise_id JOIN workouts ON we_day6.workout_id = ? GROUP BY we_day6.exercise_id');
$sentence->execute([$id]);
return $sentence->fetchAll();

}}

function not_selected_exercises6($connect){

 if (isset($_GET['id']) && !empty($_GET['id'])) {

$id = intval($_GET['id']);

$sentence = $connect->prepare('SELECT exercises.exercise_title, exercises.exercise_id, exercises.exercise_image FROM exercises WHERE exercises.exercise_id NOT IN (SELECT we_day6.exercise_id FROM we_day6 WHERE we_day6.workout_id = ? GROUP BY we_day6.exercise_id)');
$sentence->execute([$id]);
return $sentence->fetchAll();

}}

function selected_exercises7($connect){

if (isset($_GET['id']) && !empty($_GET['id'])) {

$id = intval($_GET['id']);

$sentence = $connect->prepare('SELECT exercises.exercise_title, exercises.exercise_id, exercises.exercise_image FROM exercises JOIN we_day7 ON we_day7.exercise_id = exercises.exercise_id JOIN workouts ON we_day7.workout_id = ? GROUP BY we_day7.exercise_id');
$sentence->execute([$id]);
return $sentence->fetchAll();

}}

function not_selected_exercises7($connect){

 if (isset($_GET['id']) && !empty($_GET['id'])) {

$id = intval($_GET['id']);

$sentence = $connect->prepare('SELECT exercises.exercise_title, exercises.exercise_id, exercises.exercise_image FROM exercises WHERE exercises.exercise_id NOT IN (SELECT we_day7.exercise_id FROM we_day7 WHERE we_day7.workout_id = ? GROUP BY we_day7.exercise_id)');
$sentence->execute([$id]);
return $sentence->fetchAll();

}}

function get_exercises_list($connect){

$sentence = $connect->prepare('SELECT exercises.*, GROUP_CONCAT(bodyparts.bodypart_title) AS bodypart_title FROM exercises JOIN exercises_bodyparts ON exercises_bodyparts.exercise_id = exercises.exercise_id JOIN bodyparts ON bodyparts.bodypart_id = exercises_bodyparts.bodypart_id GROUP BY exercises.exercise_id');
$sentence->execute(array());
return $sentence->fetchAll();

}

/////////////////////////////////////////////////////////////////////////////////// WORKOUTS

function get_all_workouts($connect)
{
    
    $sentence = $connect->prepare("SELECT workouts.*,goals.goal_title AS goal_title, levels.level_title AS level_title FROM workouts,goals,levels WHERE workouts.workout_goal = goals.goal_id AND workouts.workout_level = levels.level_id ORDER BY workout_id DESC"); 
    $sentence->execute();
    return $sentence->fetchAll();
}

function id_workout($id_workout){
    return (int)cleardata($id_workout);
}

function get_workout_per_id($connect, $id_workout){
    $sentence = $connect->query("SELECT workouts.*,goals.goal_title AS goal_title, levels.level_title AS level_title FROM workouts,goals,levels WHERE workouts.workout_goal = goals.goal_id AND workouts.workout_level = levels.level_id AND workout_id = $id_workout LIMIT 1");
    $sentence = $sentence->fetchAll();
    return ($sentence) ? $sentence : false;
}

function number_workouts($connect){

$total_numbers = $connect->prepare('SELECT * FROM workouts');
$total_numbers->execute(array());
$total_numbers->fetchAll();
$total = $total_numbers->rowCount();
return $total;

}

/////////////////////////////////////////////////////////////////////////////////// POSTS

function get_all_posts($connect)
{
    
    $sentence = $connect->prepare("SELECT posts.*,tags.tag_title AS tag_title FROM posts,tags WHERE posts.post_tag = tags.tag_id ORDER BY post_id DESC"); 
    $sentence->execute();
    return $sentence->fetchAll();
}

function id_post($id_post){
    return (int)cleardata($id_post);
}

function get_post_per_id($connect, $id_post){
    $sentence = $connect->query("SELECT posts.*,tags.tag_title AS tag_title FROM posts,tags WHERE post_id = $id_post AND posts.post_tag = tags.tag_id LIMIT 1");
    $sentence = $sentence->fetchAll();
    return ($sentence) ? $sentence : false;
}

function number_posts($connect){

$total_numbers = $connect->prepare('SELECT * FROM posts');
$total_numbers->execute(array());
$total_numbers->fetchAll();
$total = $total_numbers->rowCount();
return $total;

}

/////////////////////////////////////////////////////////////////////////////////// DIETS

function get_all_diets($connect)
{
    
    $sentence = $connect->prepare("SELECT diets.*,categories.category_title AS category_title FROM diets,categories WHERE diets.diet_category = categories.category_id ORDER BY diet_id DESC"); 
    $sentence->execute();
    return $sentence->fetchAll();
}

function id_diet($id_diet){
    return (int)cleardata($id_diet);
}

function get_diet_per_id($connect, $id_diet){
    $sentence = $connect->query("SELECT diets.*,categories.category_title AS category_title FROM diets,categories WHERE diet_id = $id_diet AND diets.diet_category = categories.category_id LIMIT 1");
    $sentence = $sentence->fetchAll();
    return ($sentence) ? $sentence : false;
}

function number_diets($connect){

$total_numbers = $connect->prepare('SELECT * FROM diets');
$total_numbers->execute(array());
$total_numbers->fetchAll();
$total = $total_numbers->rowCount();
return $total;

}

/////////////////////////////////////////////////////////////////////////////////// EQUIPMENTS

function get_all_equipments($connect)
{
    
    $sentence = $connect->prepare("SELECT * FROM equipments ORDER BY equipment_id DESC"); 
    $sentence->execute();
    return $sentence->fetchAll();
}

function id_equipment($id_equipment){
    return (int)cleardata($id_equipment);
}

function get_equipment_per_id($connect, $id_equipment){
    $sentence = $connect->query("SELECT * FROM equipments WHERE equipment_id = $id_equipment LIMIT 1");
    $sentence = $sentence->fetchAll();
    return ($sentence) ? $sentence : false;
}

function number_equipments($connect){

$total_numbers = $connect->prepare('SELECT * FROM equipments');
$total_numbers->execute(array());
$total_numbers->fetchAll();
$total = $total_numbers->rowCount();
return $total;

}

/////////////////////////////////////////////////////////////////////////////////// LEVELS

function get_all_levels($connect)
{
    
    $sentence = $connect->prepare("SELECT * FROM levels ORDER BY level_id DESC"); 
    $sentence->execute();
    return $sentence->fetchAll();
}

function id_level($id_level){
    return (int)cleardata($id_level);
}

function get_level_per_id($connect, $id_level){
    $sentence = $connect->query("SELECT * FROM levels WHERE level_id = $id_level LIMIT 1");
    $sentence = $sentence->fetchAll();
    return ($sentence) ? $sentence : false;
}

function number_levels($connect){

$total_numbers = $connect->prepare('SELECT * FROM levels');
$total_numbers->execute(array());
$total_numbers->fetchAll();
$total = $total_numbers->rowCount();
return $total;

}

/////////////////////////////////////////////////////////////////////////////////// QUOTES

function get_all_quotes($connect)
{
    
    $sentence = $connect->prepare("SELECT * FROM quotes ORDER BY quote_id DESC"); 
    $sentence->execute();
    return $sentence->fetchAll();
}

function id_quote($id_quote){
    return (int)cleardata($id_quote);
}

function get_quote_per_id($connect, $id_quote){
    $sentence = $connect->query("SELECT * FROM quotes WHERE quote_id = $id_quote LIMIT 1");
    $sentence = $sentence->fetchAll();
    return ($sentence) ? $sentence : false;
}

function number_quotes($connect){

$total_numbers = $connect->prepare('SELECT * FROM quotes');
$total_numbers->execute(array());
$total_numbers->fetchAll();
$total = $total_numbers->rowCount();
return $total;

}

/////////////////////////////////////////////////////////////////////////////////// CATEGORIES

function get_all_categories($connect)
{
    
    $sentence = $connect->prepare("SELECT * FROM categories ORDER BY category_id DESC"); 
    $sentence->execute();
    return $sentence->fetchAll();
}

function id_category($id_category){
    return (int)cleardata($id_category);
}

function get_category_per_id($connect, $id_category){
    $sentence = $connect->query("SELECT * FROM categories WHERE category_id = $id_category LIMIT 1");
    $sentence = $sentence->fetchAll();
    return ($sentence) ? $sentence : false;
}

function number_categories($connect){

$total_numbers = $connect->prepare('SELECT * FROM categories');
$total_numbers->execute(array());
$total_numbers->fetchAll();
$total = $total_numbers->rowCount();
return $total;

}


/////////////////////////////////////////////////////////////////////////////////// TAGS

function get_all_tags($connect)
{
    
    $sentence = $connect->prepare("SELECT * FROM tags ORDER BY tag_id DESC"); 
    $sentence->execute();
    return $sentence->fetchAll();
}

function id_tag($id_tag){
    return (int)cleardata($id_tag);
}

function get_tag_per_id($connect, $id_tag){
    $sentence = $connect->query("SELECT * FROM tags WHERE tag_id = $id_tag LIMIT 1");
    $sentence = $sentence->fetchAll();
    return ($sentence) ? $sentence : false;
}

function number_tags($connect){

$total_numbers = $connect->prepare('SELECT * FROM tags');
$total_numbers->execute(array());
$total_numbers->fetchAll();
$total = $total_numbers->rowCount();
return $total;

}

/////////////////////////////////////////////////////////////////////////////////// GOALS

function get_all_goals($connect)
{
    
    $sentence = $connect->prepare("SELECT * FROM goals ORDER BY goal_id DESC"); 
    $sentence->execute();
    return $sentence->fetchAll();
}

function id_goal($id_goal){
    return (int)cleardata($id_goal);
}

function get_goal_per_id($connect, $id_goal){
    $sentence = $connect->query("SELECT * FROM goals WHERE goal_id = $id_goal LIMIT 1");
    $sentence = $sentence->fetchAll();
    return ($sentence) ? $sentence : false;
}

function number_goals($connect){

$total_numbers = $connect->prepare('SELECT * FROM goals');
$total_numbers->execute(array());
$total_numbers->fetchAll();
$total = $total_numbers->rowCount();
return $total;

}

/////////////////////////////////////////////////////////////////////////////////// BODYPARTS

function get_all_bodyparts($connect)
{
    
    $sentence = $connect->prepare("SELECT * FROM bodyparts ORDER BY bodypart_id DESC"); 
    $sentence->execute();
    return $sentence->fetchAll();
}

function id_bodypart($id_bodypart){
    return (int)cleardata($id_bodypart);
}

function get_bodypart_per_id($connect, $id_bodypart){
    $sentence = $connect->query("SELECT * FROM bodyparts WHERE bodypart_id = $id_bodypart LIMIT 1");
    $sentence = $sentence->fetchAll();
    return ($sentence) ? $sentence : false;
}

function number_bodyparts($connect){

$total_numbers = $connect->prepare('SELECT * FROM bodyparts');
$total_numbers->execute(array());
$total_numbers->fetchAll();
$total = $total_numbers->rowCount();
return $total;

}


function selected_bodyparts($connect){

if (isset($_GET['id']) && !empty($_GET['id'])) {

$id = intval($_GET['id']);

$sentence = $connect->prepare('SELECT bodyparts.bodypart_title, bodyparts.bodypart_id, bodyparts.bodypart_image FROM bodyparts JOIN exercises_bodyparts ON exercises_bodyparts.bodypart_id = bodyparts.bodypart_id JOIN exercises ON exercises_bodyparts.exercise_id = ? GROUP BY exercises_bodyparts.bodypart_id');
$sentence->execute([$id]);
return $sentence->fetchAll();

}}

function not_selected_bodyparts($connect){

 if (isset($_GET['id']) && !empty($_GET['id'])) {

$id = intval($_GET['id']);

$sentence = $connect->prepare('SELECT bodyparts.bodypart_title, bodyparts.bodypart_id, bodyparts.bodypart_image FROM bodyparts WHERE bodyparts.bodypart_id NOT IN (SELECT exercises_bodyparts.bodypart_id FROM exercises_bodyparts WHERE exercises_bodyparts.exercise_id = ? GROUP BY exercises_bodyparts.bodypart_id)');
$sentence->execute([$id]);
return $sentence->fetchAll();

}}


/////////////////////////////////////////////////////////////////////////////////// CUSTOMS

function randomPassword() {
     
	$alphabet = '1234567890';
	$pass = array(); //remember to declare $pass as an array
	$alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
	for ($i = 0; $i < 5; $i++) {
    	$n = rand(0, $alphaLength);
    	$pass[] = $alphabet[$n];
	}
	return implode($pass); //turn the array into a string
}

function isEmailValid($email) {

    return filter_var($email, FILTER_VALIDATE_EMAIL) !== FALSE;
}

function get_all_settings($connect)
{
    
    $sentence = $connect->query("SELECT * FROM settings"); 
    $sentence->execute();
    return $sentence->fetchAll();
}

function get_all_strings($connect)
{
    
    $sentence = $connect->query("SELECT * FROM strings"); 
    $sentence->execute();
    return $sentence->fetchAll();
}

function fecha($fecha){

    $timestamp = strtotime($fecha);
    $meses = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    $dia = date('d', $timestamp);
    $mes = date('m', $timestamp) - 1;
    $ano = date('Y', $timestamp);

    $fecha = "$dia " . $meses[$mes] . " $ano";
    return $fecha;
}

function time_ago($date) {
    if (empty($date)) {
        return "-";
    }
    $periods = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
    $lengths = array("60", "60", "24", "7", "4.35", "12", "10");
    $now = time();
    $uni_date = strtotime($date);
// check validity of date
    if (empty($uni_date)) {
        return "-";
    }
// is it future date or past date
    if ($now > $uni_date) {
        $difference = $now - $uni_date;
        $tense = "ago";
    } else {
        $difference = $uni_date - $now;
        $tense = "from now";
    }
    for ($j = 0; $difference >= $lengths[$j] && $j < count($lengths) - 1; $j++) {
        $difference /= $lengths[$j];
    }
    $difference = round($difference);
    if ($difference != 1) {
        $periods[$j].= "s";
    }
    return "$difference $periods[$j] {$tense}";
}

function checkRemoteFile($url)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,$url);
    // don't download content
    curl_setopt($ch, CURLOPT_NOBODY, 1);
    curl_setopt($ch, CURLOPT_FAILONERROR, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    $result = curl_exec($ch);
    curl_close($ch);
    if($result !== FALSE)
    {
        return true;
    }
    else
    {
        return false;
    }
}

function getHash($password) {
     
    $salt = sha1(rand());
    $salt = substr($salt, 0, 10);
    $encrypted = password_hash(trim($password.$salt), PASSWORD_DEFAULT);
    $hash = array("salt" => $salt, "encrypted" => $encrypted);
    return $hash;
}
     
function verifyHash($password, $hash) {
     
    return password_verify($password, $hash);
}

function getApplicationEmail() {

    $emailAddress = "rabiaah@gmail.com";
    return $emailAddress;
}

function getSupportEmail() {

    $emailAddress = "rabiaah@gmail.com"; 
    return $emailAddress;
}

function getAdminEmail() {

    $emailAddress = "rabiaah@gmail.com"; 
    return $emailAddress;
}

function getApplicationName() {

    $businessName = "Fitness";
    return $businessName;
}

function getApplicationDetails() {

    $businessName = "Fitness, by Rabia Abu hanna" . "<br /><br />";
    $businessAddress = "Nazareth, Israel" . "<br />";
    $businessPhone = "052-4555844";
    return $businessName . $businessAddress . $businessPhone;
}

function sendEmail($to, $subject, $message) {

    $message = "<html><head><title>" . $this->getApplicationName() . "</title></head><body style='direction:rtl; font-size: 14px;color:".TEXT_COLOR.";'><h2 style='font-size: 18px;color:".APPLICATION_COLOR.";'>" . $this->getApplicationName() . "</h2><p>" . $message . "</p></body></html>";
    
    $mail = $this->mail;
    $mail->addAddress($to);
    $addresses = explode(',', $this->getSupportEmail());
    foreach ($addresses as $address) {
        $mail->addBCC($address);
    }
    $mail->Subject = $subject;
    $mail->Body    = $message;
    $mail->AltBody = $message;
    $mail->send();
}

function sendPrivateEmail($to, $subject, $message) {

    $message = "<html><head><title>" . $this->getApplicationName() . "</title></head><body style='direction:rtl; font-size: 14px;color:".TEXT_COLOR.";'><h2 style='font-size: 18px;color:".APPLICATION_COLOR.";'>" . $this->getApplicationName() . "</h2><p>" . $message . "</p></body></html>";
    
    $mail = $this->mail;
    $mail->addAddress($to);
    $addresses = explode(',', $this->getAdminEmail());
    foreach ($addresses as $address) {
        $mail->addBCC($address);
    }
    $mail->Subject = $subject;
    $mail->Body    = $message;
    $mail->AltBody = $message;
    $mail->send();
}

?>
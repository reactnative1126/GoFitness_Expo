<?php 

session_start();
require '../admin/config.php';

if (isset($_SESSION['username'])){
    
    require '../admin/functions.php';
    require '../views/header.view.php';
    require '../views/navbar.view.php'; 
    
    $errors = '';
    
    $connect = connect($database);
    if(!$connect){
    	header('Location: ' . SITE_URL . '/controller/error.php');
    	} 
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    	
    	$event_date = $_POST['event_date'];
    	$event_start_time = $_POST['event_start_time'];
    	$event_end_time = $_POST['event_end_time'];
    	$event_availability = $_POST['event_availability'];
    	$event_scheduled_date = $_POST['event_scheduled_date'];
    	$event_scheduled_time = $_POST['event_scheduled_time'];
    	$coach_id = $_POST['coach_id'];
    	$class_id = $_POST['class_id'];
    	$place_id = $_POST['place_id'];
    	$event_private = $_POST['event_private'];
    	$event_status = $_POST['event_status'];
    	
    	if (check_event_exist($connect, $event_date, $event_start_time, $event_end_time, $place_id) > 0){
            
            $errors.=_ERROR_EVENT_EXISTS;
        }
        else {
    	    
    	    $statment = $connect->prepare(
    		'INSERT INTO TABLE_EVENT (event_date, event_start_time, event_end_time, event_availability, event_status, event2class, event2place, event_scheduled_date, event_scheduled_time, event_private, event_scheduled_date_backup, event_scheduled_time_backup, event2coach) VALUES (:event_date, :event_start_time, :event_end_time, :event_availability, :event_status, :class_id, :place_id, (case when (:event_scheduled_date IS NOT NULL) then :event_scheduled_date else NULL end), (case when (:event_scheduled_time IS NOT NULL) then :event_scheduled_time else NULL end), :event_private, event_scheduled_date, event_scheduled_time, :coach_id)'
    		);
    		
        	$statment->execute(array(
        		':event_date' => $event_date,
        		':event_start_time' => $event_start_time,
        		':event_end_time' => $event_end_time,
        		':event_availability' => $event_availability,
        		':event_scheduled_date' => $event_scheduled_date,
        		':event_scheduled_time' => $event_scheduled_time,
        		':coach_id' => $coach_id,
        		':class_id' => $class_id,
        		':place_id' => $place_id,
        		':event_private' => $event_private,
        		':event_status' => $event_status
        		));
        }
        
        if (empty($errors)) {
            header('Location:' . SITE_URL . '/controller/events.php');
        }
        
    }
    else{
        
        $id = id_event($_GET['id']);
        
        if(!empty($id)){
    	    
    	    $event = get_event_per_id($connect, $id);
    	    
            if (!$event){
                header('Location: ' . SITE_URL . '/controller/home.php');
            }
        
            $event = $event['0'];
            $event_date = "";
        	$event_start_time = $event['event_start_time'];
        	$event_end_time = $event['event_end_time'];
        	$event_availability = $event['event_availability'];
        	$event_scheduled_date = $event['event_scheduled_date'];
        	$event_scheduled_time = $event['event_scheduled_time'];
        	$coach_id = $event['coach_id'];
        	$class_id = $event['class_id'];
        	$place_id = $event['place_id'];
        	$event_private = $event['event_private'];
        	$event_status = $event['event_status'];
    	}
    }
    
    $coaches = get_all_coaches($connect);
    $classes = get_all_classes($connect);
    $places = get_all_places($connect);
    
    require '../views/new.event.view.php';
    require '../views/footer.view.php';
}
else {
		header('Location: ' . SITE_URL . '/controller/login.php');		
}

?>
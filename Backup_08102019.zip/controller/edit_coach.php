<?php 

session_start();
require '../admin/config.php';

if (isset($_SESSION['username'])){
    
    require '../admin/functions.php';
    require '../views/header.view.php';
    require '../views/navbar.view.php';
    
    $connect = connect($database);
    if(!$connect){
        
    	header ('Location: ' . SITE_URL . '/controller/error.php');
    }
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    
    	$coach_id = $_POST['coach_id'];
    	$coach_name = cleardata($_POST['coach_name']);
    	$coach_details = cleardata($_POST['coach_details']);
    	$coach_status = $_POST['coach_status'];
    	$coach_image_save = $_POST['coach_image_save'];
    	$coach_image = $_FILES['coach_image'];
    
    	if (empty($coach_image['name'])) {
    		$coach_image = $coach_image_save;
    	}
    	else{
			$imagefile = explode(".", $_FILES["coach_image"]["name"]);
			$renamefile = round(microtime(true)) . '.' . end($imagefile);
		    $coach_image_upload = '../' . $items_config['images_folder'].'coaches/';
		    move_uploaded_file($_FILES['coach_image']['tmp_name'], $coach_image_upload . 'coach_img_' . $renamefile);
		    $coach_image = 'coach_img_' . $renamefile;
    	}
    	
    	$statment = $connect->prepare('UPDATE TABLE_COACH SET coach_name=:coach_name, coach_details=:coach_details, coach_image=:coach_image, coach_status=:coach_status WHERE objid=:coach_id');
    	
    	$statment->execute(array(
    
    		':coach_id' => $coach_id,
    		':coach_name' => $coach_name,
    		':coach_details' => $coach_details,
    		':coach_image' => $coach_image,
    		':coach_status' => $coach_status
    		));
    	
    	header('Location:' . SITE_URL . '/controller/coaches.php');
    
    } 
    else{
    
        $coach_id = id_coach($_GET['coach_id']);
        
        if(empty($coach_id)){
    	    header('Location: home.php');
    	}
    
        $coach = get_coach_per_id($connect, $coach_id);
        
        if (!$coach){
            header('Location: ' . SITE_URL . '/controller/home.php');
        }
    
        $coach = $coach['0'];
    }
    
    require '../views/edit.coach.view.php';
    require '../views/footer.view.php';
}
else {
		header('Location: ' . SITE_URL . '/controller/login.php');		
}

?>
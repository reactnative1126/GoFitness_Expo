<?php 

session_start();
require '../admin/config.php';

if (isset($_SESSION['username'])){
    
    require '../admin/functions.php';
    require '../views/header.view.php';
    require '../views/navbar.view.php';
    
    $connect = connect($database);
    if(!$connect){
        
    	header ('Location: ' . SITE_URL . '/controller/error.php');
    }
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    
        $group_active_users = $_POST['user_id'];
        
    	$group_id = $_POST['group_id'];
    	$group_name = cleardata($_POST['group_name']);
    	$group_details = cleardata($_POST['group_details']);
    	$group_status = $_POST['group_status'];
    	
    	$statment = $connect->prepare('UPDATE TABLE_GROUP SET group_name=:group_name, group_details=:group_details, group_status=:group_status WHERE objid=:group_id');
    	
    	$statment->execute(array(
    
    		':group_id' => $group_id,
    		':group_name' => $group_name,
    		':group_details' => $group_details,
    		':group_status' => $group_status
    		));
    	
    	$statment = $connect->prepare('DELETE FROM TABLE_GROUP_USERS WHERE groupusers2group=:group_id');
        $statment->bindParam(':group_id', $group_id);
        $statment->execute();
        
        $statment = $connect->prepare( 'INSERT INTO TABLE_GROUP_USERS (groupusers2group,groupusers2user) VALUES (:group_id, :user_id)' );
        $statment->bindParam(':user_id', $user_id);
        $statment->bindParam(':group_id', $group_id);
        
        $statment->execute();
        
        foreach ($group_active_users as $option_value)
        {
           $user_id = $option_value;
           $statment->execute();
        }
        
    	header('Location:' . SITE_URL . '/controller/groups.php');
    } 
    else{
    
        $group_id = id_group($_GET['group_id']);
        
        if(empty($group_id)){
    	    header('Location: home.php');
    	}
    
        $group = get_group_per_id($connect, $group_id);
        
        if (!$group){
            header('Location: ' . SITE_URL . '/controller/home.php');
        }
        
        $group = $group['0'];
    }
    
    $group_active_users = group_active_users($connect);
    $group_selected_users = group_selected_users($connect);
    $group_not_selected_users = group_not_selected_users($connect);
    
    require '../views/edit.group.view.php';
    require '../views/footer.view.php';
}
else {
		header('Location: ' . SITE_URL . '/controller/login.php');		
}

?>
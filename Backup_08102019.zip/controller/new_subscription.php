<?php 

session_start();
require '../admin/config.php';

if (isset($_SESSION['username'])){
    
    require '../admin/functions.php';
    require '../views/header.view.php';
    require '../views/navbar.view.php'; 
    
    $errors = '';
    
    $connect = connect($database);
    if(!$connect){
    	header('Location: ' . SITE_URL . '/controller/error.php');
    	} 
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    	
    	$subscription_name = cleardata($_POST['subscription_name']);
    	$subscription_details = cleardata($_POST['subscription_details']);
    	$subscription_period = $_POST['subscription_period'];
    	$subscription_bank = $_POST['subscription_bank'];
    	$subscription_price = $_POST['subscription_price'];
    	$subscription_status = $_POST['subscription_status'];
    	
    	$statment = $connect->prepare(
    		'INSERT INTO TABLE_SUBSCRIPTION (subscription_name, subscription_details, subscription_status, subscription_period, subscription_bank, subscription_price) VALUES (:subscription_name, :subscription_details, :subscription_status, :subscription_period, :subscription_bank, :subscription_price)'
    		);
    		
    	$statment->execute(array(
    		':subscription_name' => $subscription_name,
    		':subscription_details' => $subscription_details,
    		':subscription_period' => $subscription_period,
    		':subscription_bank' => $subscription_bank,
    		':subscription_price' => $subscription_price,
    		':subscription_status' => $subscription_status
    		));
    
    	header('Location:' . SITE_URL . '/controller/subscriptions.php');
    	
    }
    
    require '../views/new.subscription.view.php';
    require '../views/footer.view.php';
}
else {
		header('Location: ' . SITE_URL . '/controller/login.php');		
}

?>
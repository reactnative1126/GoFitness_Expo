<?php 

session_start();
require '../admin/config.php';

if (isset($_SESSION['username'])){
    
    require '../admin/functions.php';
    require '../views/header.view.php';
    require '../views/navbar.view.php'; 
    
    $connect = connect($database);
    if(!$connect){
    	header ('Location: ' . SITE_URL . '/controller/error.php');
    	}
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    
        $place_id = cleardata($_POST['place_id']);
        $place_name = cleardata($_POST['place_name']);
    	$place_latitude = $_POST['place_latitude'];
    	$place_longitude = $_POST['place_longitude'];
    	$place_status = $_POST['place_status'];
    	
    $statment = $connect->prepare(
    	'UPDATE TABLE_PLACE SET place_name=:place_name, place_latitude=:place_latitude, place_longitude=:place_longitude, place_status=:place_status WHERE objid = :place_id'
    	);
    
    $statment->execute(array(
    
            ':place_id' => $place_id,
    		':place_name' => $place_name,
    		':place_latitude' => $place_latitude,
    		':place_longitude' => $place_longitude,
    		':place_status' => $place_status
    ));
    
    header('Location:' . SITE_URL . '/controller/places.php');
    
    } else{
    
    $place_id = id_place($_GET['place_id']);
        
    if(empty($place_id)){
    	header('Location: ' . SITE_URL . '/controller/home.php');
    }
    
    $place = get_place_per_id($connect, $place_id);
        
        if (!$place){
        header('Location: ' . SITE_URL . '/controller/home.php');
    }
    
    $place = $place['0'];
    
    }
    
    require '../views/edit.place.view.php';
    require '../views/footer.view.php';
        
} 
else {
		header('Location: ' . SITE_URL . '/controller/login.php');		
}

?>
<?php 

session_start();
require '../admin/config.php';

if (isset($_SESSION['username'])){
    
    require '../admin/functions.php';
    require '../views/header.view.php';
    require '../views/navbar.view.php'; 
    
    $errors = '';
    
    $connect = connect($database);
    if(!$connect){
    	header('Location: ' . SITE_URL . '/controller/error.php');
    	} 
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    	
    	$coach_name = cleardata($_POST['coach_name']);
    	$coach_details = $_POST['coach_details'];
    	$coach_status = $_POST['coach_status'];
    	$coach_image = $_FILES['coach_image']['tmp_name'];
    	
    	$imagefile = explode(".", $_FILES["coach_image"]["name"]);
    	$renamefile = round(microtime(true)) . '.' . end($imagefile);
    	$coach_image_upload = '../' . $items_config['images_folder'].'coaches/';
    	move_uploaded_file($coach_image, $coach_image_upload . 'coach_img_' . $renamefile);
    	
    	$statment = $connect->prepare(
    		'INSERT INTO TABLE_COACH (coach_name, coach_details, coach_image, coach_status) VALUES (:coach_name, :coach_details, :coach_image, :coach_status)'
    		);
    		
    	$statment->execute(array(
    		':coach_name' => $coach_name,
    		':coach_details' => $coach_details,
    		':coach_image' => 'coach_img_' . $renamefile,
    		':coach_status' => $coach_status
    		));
    
    	header('Location:' . SITE_URL . '/controller/coaches.php');
    	
    }
    
    require '../views/new.coach.view.php';
    require '../views/footer.view.php';
}
else {
		header('Location: ' . SITE_URL . '/controller/login.php');		
}

?>
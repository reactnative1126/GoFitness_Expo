<?php

session_start();
require '../admin/config.php';

if (isset($_SESSION['username'])){

    require '../admin/functions.php';	
    require '../views/header.view.php';
    require '../views/navbar.view.php';    
    
    $errors = '';   
    
    $connect = connect($database);
    if(!$connect){
    	header('Location: ' . SITE_URL . '/controller/error.php');
    	}
    
    $filter = $_GET['filter'];
    switch($filter){
        case 'active_users': 
            $users = get_active_users($connect);
            break;
        case 'inactive_users': 
            $users = get_inactive_users($connect);
            break;
        case 'users_with_no_membership': 
            $users = get_users_with_no_membership($connect);
            break;
        case 'expired_users': 
            $users = get_expired_users($connect);
            break;
        case 'expired_soon_users': 
            $users = get_expired_soon_users($connect);
            break;
        case 'freezed_users': 
            $users = get_freezed_users($connect);
            break;
        case 'not_enrolled_users': 
            $users = get_not_enrolled_users($connect);
            break;
        default: $users = get_all_users($connect);
    }
    
    if (empty($users)){
         $errors .='<div style="padding: 0px 15px;">No data found</div>';
    }
    
    $users_total = number_users($connect);
    
    require '../views/users.view.php';
    require '../views/footer.view.php';
        
}
else {
	header('Location: ' . SITE_URL . '/controller/login.php');		
}
?>
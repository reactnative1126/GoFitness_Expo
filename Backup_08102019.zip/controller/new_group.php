<?php 

session_start();
require '../admin/config.php';

if (isset($_SESSION['username'])){
    
    require '../admin/functions.php';
    require '../views/header.view.php';
    require '../views/navbar.view.php'; 
    
    $errors = '';
    
    $connect = connect($database);
    if(!$connect){
    	header('Location: ' . SITE_URL . '/controller/error.php');
    	} 
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    	
    	$group_name = cleardata($_POST['group_name']);
    	$group_details = $_POST['group_details'];
    	$group_status = $_POST['group_status'];
    	
    	$statment = $connect->prepare(
    		'INSERT INTO TABLE_GROUP (group_name, group_details, group_status) VALUES (:group_name, :group_details, :group_status)'
    		);
    		
    	$statment->execute(array(
    		':group_name' => $group_name,
    		':group_details' => $group_details,
    		':group_status' => $group_status
    		));
    
    	header('Location:' . SITE_URL . '/controller/groups.php');
    	
    }
    
    require '../views/new.group.view.php';
    require '../views/footer.view.php';
}
else {
		header('Location: ' . SITE_URL . '/controller/login.php');		
}

?>
<?php

session_start();
require '../admin/config.php';

if (isset($_SESSION['username'])){
    
    require '../admin/functions.php';	
    require '../views/header.view.php';
    require '../views/navbar.view.php';    
    
    $errors = '';   
    $date = date('Y-m-d');
    
    $connect = connect($database);
    if(!$connect){
    	header('Location: ' . SITE_URL . '/controller/error.php');
    }
    
    $events = get_all_events($connect);
     if (empty($events)){
         $errors .='<div style="padding: 0px 15px;">No data found</div>';
    }
    
    $events_total = number_events($connect, $date);
    
    require '../views/events.view.php';
    require '../views/footer.view.php';
        
}
else {
		header('Location: ' . SITE_URL . '/controller/login.php');		
}

?>
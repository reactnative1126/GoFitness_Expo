<?php 

session_start();
require '../admin/config.php';

if (isset($_SESSION['username'])){
    
    require '../admin/functions.php';
    require '../views/header.view.php';
    require '../views/navbar.view.php'; 
    
    $errors = '';
    
    $connect = connect($database);
    if(!$connect){
    	header('Location: ' . SITE_URL . '/controller/error.php');
    	} 
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    	
    	$payment_datetime = cleardata($_POST['payment_datetime']);
    	$payment_acceptance = cleardata($_POST['payment_acceptance']);
    	$payment_method = cleardata($_POST['payment_method']);
    	$payment_card_month = $_POST['payment_card_month'];
    	$payment_card_year = cleardata($_POST['payment_card_year']);
    	$payment_last_digits = $_POST['payment_last_digits'];
    	$payment_details = $_POST['payment_details'];
    	
    // 	$statment = $connect->prepare(
    // 		'INSERT INTO TABLE_CLASS (class_name, class_details, class_image, class_status) VALUES (:class_name, :class_details, :class_image, :class_status)'
    // 		);
    		
    	$statment->execute(array(
    		':payment_datetime' => $payment_datetime
    		));
    
    	header('Location:' . SITE_URL . '/controller/payments.php');
    	
    }
    
    require '../views/new.payment.view.php';
    require '../views/footer.view.php';
}
else {
		header('Location: ' . SITE_URL . '/controller/login.php');		
}

?>
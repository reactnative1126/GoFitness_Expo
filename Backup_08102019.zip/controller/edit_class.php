<?php 

session_start();
require '../admin/config.php';

if (isset($_SESSION['username'])){
    
    require '../admin/functions.php';
    require '../views/header.view.php';
    require '../views/navbar.view.php';
    
    $connect = connect($database);
    if(!$connect){
        
    	header ('Location: ' . SITE_URL . '/controller/error.php');
    }
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    
    	$class_id = $_POST['class_id'];
    	$class_name = cleardata($_POST['class_name']);
    	$class_details = cleardata($_POST['class_details']);
    	$class_status = $_POST['class_status'];
    	$class_image_save = $_POST['class_image_save'];
    	$class_image = $_FILES['class_image'];
    
    	if (empty($class_image['name'])) {
    		$class_image = $class_image_save;
    	}
    	else{
			$imagefile = explode(".", $_FILES["class_image"]["name"]);
			$renamefile = round(microtime(true)) . '.' . end($imagefile);
		    $class_image_upload = '../' . $items_config['images_folder'].'classes/';
		    move_uploaded_file($_FILES['class_image']['tmp_name'], $class_image_upload . 'class_img_' . $renamefile);
		    $class_image = 'class_img_' . $renamefile;
    	}
    	
    	$statment = $connect->prepare('UPDATE TABLE_CLASS SET class_name=:class_name, class_details=:class_details, class_image=:class_image, class_status=:class_status WHERE objid=:class_id');
    	
    	$statment->execute(array(
    
    		':class_id' => $class_id,
    		':class_name' => $class_name,
    		':class_details' => $class_details,
    		':class_image' => $class_image,
    		':class_status' => $class_status
    		));
    	
    	header('Location:' . SITE_URL . '/controller/classes.php');
    
    } 
    else{
    
        $class_id = id_class($_GET['class_id']);
        
        if(empty($class_id)){
    	    header('Location: home.php');
    	}
    
        $class = get_class_per_id($connect, $class_id);
        
        if (!$class){
            header('Location: ' . SITE_URL . '/controller/home.php');
        }
    
        $class = $class['0'];
    }
    
    require '../views/edit.class.view.php';
    require '../views/footer.view.php';
}
else {
		header('Location: ' . SITE_URL . '/controller/login.php');		
}

?>
<?php

include '../admin/config.php';

$conn = new mysqli($database['host'],$database['user'], $database['pass'], $database['db']);



 ?>

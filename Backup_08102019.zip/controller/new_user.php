<?php 

session_start();
require '../admin/config.php';

if (isset($_SESSION['username'])){
    
    require '../admin/functions.php';
    require '../views/header.view.php';
    require '../views/navbar.view.php'; 
    
    $errors = '';
    $user_status = '1';
    
    $connect = connect($database);
    if(!$connect){
    	header('Location: ' . SITE_URL . '/controller/error.php');
    	} 
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
        
    	$user_name = cleardata($_POST['user_name']);
    	$user_id = cleardata($_POST['user_id']);
    	$user_phone = cleardata($_POST['user_phone']);
    	$user_email = $_POST['user_email'];
    	$user_sex = $_POST['user_sex'];
    	$birthday = $_POST['birthday'];
    	$user_weight = $_POST['user_weight'];
    	$user_height = $_POST['user_height'];
    	$user_image = $_FILES['user_image']['tmp_name'];
    	$user_status = $_POST['user_status'];
    	
    	$imagefile = explode(".", $_FILES["user_image"]["name"]);
    	$renamefile = round(microtime(true)) . '.' . end($imagefile);
    	$user_image_upload = '../' . $items_config['images_folder'].'users/';
    	move_uploaded_file($user_image, $user_image_upload . 'user_img_' . $renamefile);
    	
    	$password = randomPassword();
    	$unique_id = uniqid('', true);
    	$hash = getHash($password);
    	$encrypted_password = $hash["encrypted"];
    	$salt = $hash["salt"];
    	
        if (check_user_email($connect, $user_email) || check_user_id($connect, $user_id) ){
            
            $errors.='Email Address or User Id already exists in the system!';
        }
        else {
    	    
            $statment = $connect->prepare(
    		'INSERT INTO TABLE_USER (unique_id, name, email, encrypted_password, salt, phone, created_at, user_id, user_weight, user_height, user_sex, subs_created_at, user_image, user_status, user_birthdate) VALUES (:unique_id, :user_name, :user_email, :encrypted_password, :salt, :user_phone, NOW(), :user_id, :user_weight, :user_height, :user_sex, DATE(NOW()), :user_image, :user_status, Date(:birthday))'
    		);
        	
        	$statment->execute(array(
        	    ':salt' => $salt,
        	    ':encrypted_password' => $encrypted_password,
        	    ':unique_id' => $unique_id,
        		':user_name' => $user_name,
        		':user_id' => $user_id,
        		':user_phone' => $user_phone,
        		':user_email' => $user_email,
        		':user_sex' => $user_sex,
        		':birthday' => $birthday,
        		':user_weight' => $user_weight,
        		':user_height' => $user_height,
        		':user_image' => 'user_img_' . $renamefile,
        		':user_status' => $user_status
        		));
        }
        
        if (empty($errors)) {
            header('Location:' . SITE_URL . '/controller/users.php');
        }
    }
    
    require '../views/new.user.view.php';
    require '../views/footer.view.php';
}
else {
		header('Location: ' . SITE_URL . '/controller/login.php');		
}

?>
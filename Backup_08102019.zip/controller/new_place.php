<?php 

session_start();
require '../admin/config.php';

if (isset($_SESSION['username'])){
    
    require '../admin/functions.php';
    require '../views/header.view.php';
    require '../views/navbar.view.php'; 
    
    $errors = '';
    
    $connect = connect($database);
    if(!$connect){
    	header('Location: ' . SITE_URL . '/controller/error.php');
    	} 
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
        
    	$place_name = cleardata($_POST['place_name']);
    	$place_latitude = $_POST['place_latitude'];
    	$place_longitude = $_POST['place_longitude'];
    	$place_status = $_POST['place_status'];
    	
    	$statment = $connect->prepare(
    		'INSERT INTO TABLE_PLACE (place_name, place_latitude, place_longitude, place_status) VALUES (:place_name, :place_latitude, :place_longitude, :place_status)'
    		);
    	
    	$statment->execute(array(
    		':place_name' => $place_name,
    		':place_latitude' => $place_latitude,
    		':place_longitude' => $place_longitude,
    		':place_status' => $place_status
    	));
    
    	header('Location:' . SITE_URL . '/controller/places.php');
    
    }
    
    require '../views/new.place.view.php';
    require '../views/footer.view.php';
        
}
else {
		header('Location: ' . SITE_URL . '/controller/login.php');		
}

?>